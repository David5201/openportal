/*    */ package com.alipay.config;
/*    */ 
/*    */ public class AlipayConfig
/*    */ {
/* 19 */   public static String sign_type = "MD5";
/*    */ 
/* 22 */   public static String input_charset = "utf-8";
/*    */ 
/* 25 */   public static String payment_type = "1";
/*    */ 
/* 28 */   public static String service = "create_direct_pay_by_user";
/*    */ 
/* 36 */   public static String anti_phishing_key = "";
/*    */ 
/* 39 */   public static String exter_invoke_ip = "";
/*    */ }

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.alipay.config.AlipayConfig
 * JD-Core Version:    0.6.2
 */