/*    */ package com.alipay.util.httpClient;
/*    */ 
/*    */ public enum HttpResultType
/*    */ {
/* 18 */   STRING, 
/*    */ 
/* 23 */   BYTES;
/*    */ }

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.alipay.util.httpClient.HttpResultType
 * JD-Core Version:    0.6.2
 */