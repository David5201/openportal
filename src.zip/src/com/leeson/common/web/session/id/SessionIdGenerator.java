package com.leeson.common.web.session.id;

public abstract interface SessionIdGenerator
{
  public abstract String get();
}

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.common.web.session.id.SessionIdGenerator
 * JD-Core Version:    0.6.2
 */