package com.leeson.common.web.springmvc;

public abstract interface RealPathResolver
{
  public abstract String get(String paramString);
}

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.common.web.springmvc.RealPathResolver
 * JD-Core Version:    0.6.2
 */