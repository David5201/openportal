/*     */ package com.leeson.core.query;
/*     */ 
/*     */ public class PortalbasauthView
/*     */ {
/*     */   private String username0;
/*     */   private String password0;
/*     */   private String url0;
/*     */   private Long time0;
/*     */   private String username1;
/*     */   private String password1;
/*     */   private String url1;
/*     */   private Long time1;
/*     */   private String username2;
/*     */   private String password2;
/*     */   private String url2;
/*     */   private Long time2;
/*     */   private String username3;
/*     */   private String password3;
/*     */   private String url3;
/*     */   private Long time3;
/*     */   private String username4;
/*     */   private String password4;
/*     */   private String url4;
/*     */   private Long time4;
/*     */   private String username5;
/*     */   private String password5;
/*     */   private String url5;
/*     */   private Long time5;
/*     */   private String username6;
/*     */   private String password6;
/*     */   private String url6;
/*     */   private Long time6;
/*     */   private String username7;
/*     */   private String password7;
/*     */   private String url7;
/*     */   private Long time7;
/*     */ 
/*     */   public String getUsername0()
/*     */   {
/*  47 */     return this.username0;
/*     */   }
/*     */   public void setUsername0(String username0) {
/*  50 */     this.username0 = username0;
/*     */   }
/*     */   public String getPassword0() {
/*  53 */     return this.password0;
/*     */   }
/*     */   public void setPassword0(String password0) {
/*  56 */     this.password0 = password0;
/*     */   }
/*     */   public String getUrl0() {
/*  59 */     return this.url0;
/*     */   }
/*     */   public void setUrl0(String url0) {
/*  62 */     this.url0 = url0;
/*     */   }
/*     */   public Long getTime0() {
/*  65 */     return this.time0;
/*     */   }
/*     */   public void setTime0(Long time0) {
/*  68 */     this.time0 = time0;
/*     */   }
/*     */   public String getUsername1() {
/*  71 */     return this.username1;
/*     */   }
/*     */   public void setUsername1(String username1) {
/*  74 */     this.username1 = username1;
/*     */   }
/*     */   public String getPassword1() {
/*  77 */     return this.password1;
/*     */   }
/*     */   public void setPassword1(String password1) {
/*  80 */     this.password1 = password1;
/*     */   }
/*     */   public String getUrl1() {
/*  83 */     return this.url1;
/*     */   }
/*     */   public void setUrl1(String url1) {
/*  86 */     this.url1 = url1;
/*     */   }
/*     */   public Long getTime1() {
/*  89 */     return this.time1;
/*     */   }
/*     */   public void setTime1(Long time1) {
/*  92 */     this.time1 = time1;
/*     */   }
/*     */   public String getUsername2() {
/*  95 */     return this.username2;
/*     */   }
/*     */   public void setUsername2(String username2) {
/*  98 */     this.username2 = username2;
/*     */   }
/*     */   public String getPassword2() {
/* 101 */     return this.password2;
/*     */   }
/*     */   public void setPassword2(String password2) {
/* 104 */     this.password2 = password2;
/*     */   }
/*     */   public String getUrl2() {
/* 107 */     return this.url2;
/*     */   }
/*     */   public void setUrl2(String url2) {
/* 110 */     this.url2 = url2;
/*     */   }
/*     */   public Long getTime2() {
/* 113 */     return this.time2;
/*     */   }
/*     */   public void setTime2(Long time2) {
/* 116 */     this.time2 = time2;
/*     */   }
/*     */   public String getUsername3() {
/* 119 */     return this.username3;
/*     */   }
/*     */   public void setUsername3(String username3) {
/* 122 */     this.username3 = username3;
/*     */   }
/*     */   public String getPassword3() {
/* 125 */     return this.password3;
/*     */   }
/*     */   public void setPassword3(String password3) {
/* 128 */     this.password3 = password3;
/*     */   }
/*     */   public String getUrl3() {
/* 131 */     return this.url3;
/*     */   }
/*     */   public void setUrl3(String url3) {
/* 134 */     this.url3 = url3;
/*     */   }
/*     */   public Long getTime3() {
/* 137 */     return this.time3;
/*     */   }
/*     */   public void setTime3(Long time3) {
/* 140 */     this.time3 = time3;
/*     */   }
/*     */   public String getUsername4() {
/* 143 */     return this.username4;
/*     */   }
/*     */   public void setUsername4(String username4) {
/* 146 */     this.username4 = username4;
/*     */   }
/*     */   public String getPassword4() {
/* 149 */     return this.password4;
/*     */   }
/*     */   public void setPassword4(String password4) {
/* 152 */     this.password4 = password4;
/*     */   }
/*     */   public String getUrl4() {
/* 155 */     return this.url4;
/*     */   }
/*     */   public void setUrl4(String url4) {
/* 158 */     this.url4 = url4;
/*     */   }
/*     */   public Long getTime4() {
/* 161 */     return this.time4;
/*     */   }
/*     */   public void setTime4(Long time4) {
/* 164 */     this.time4 = time4;
/*     */   }
/*     */   public String getUsername5() {
/* 167 */     return this.username5;
/*     */   }
/*     */   public void setUsername5(String username5) {
/* 170 */     this.username5 = username5;
/*     */   }
/*     */   public String getPassword5() {
/* 173 */     return this.password5;
/*     */   }
/*     */   public void setPassword5(String password5) {
/* 176 */     this.password5 = password5;
/*     */   }
/*     */   public String getUrl5() {
/* 179 */     return this.url5;
/*     */   }
/*     */   public void setUrl5(String url5) {
/* 182 */     this.url5 = url5;
/*     */   }
/*     */   public Long getTime5() {
/* 185 */     return this.time5;
/*     */   }
/*     */   public void setTime5(Long time5) {
/* 188 */     this.time5 = time5;
/*     */   }
/*     */   public String getUsername6() {
/* 191 */     return this.username6;
/*     */   }
/*     */   public void setUsername6(String username6) {
/* 194 */     this.username6 = username6;
/*     */   }
/*     */   public String getPassword6() {
/* 197 */     return this.password6;
/*     */   }
/*     */   public void setPassword6(String password6) {
/* 200 */     this.password6 = password6;
/*     */   }
/*     */   public String getUrl6() {
/* 203 */     return this.url6;
/*     */   }
/*     */   public void setUrl6(String url6) {
/* 206 */     this.url6 = url6;
/*     */   }
/*     */   public Long getTime6() {
/* 209 */     return this.time6;
/*     */   }
/*     */   public void setTime6(Long time6) {
/* 212 */     this.time6 = time6;
/*     */   }
/*     */   public String getUsername7() {
/* 215 */     return this.username7;
/*     */   }
/*     */   public void setUsername7(String username7) {
/* 218 */     this.username7 = username7;
/*     */   }
/*     */   public String getPassword7() {
/* 221 */     return this.password7;
/*     */   }
/*     */   public void setPassword7(String password7) {
/* 224 */     this.password7 = password7;
/*     */   }
/*     */   public String getUrl7() {
/* 227 */     return this.url7;
/*     */   }
/*     */   public void setUrl7(String url7) {
/* 230 */     this.url7 = url7;
/*     */   }
/*     */   public Long getTime7() {
/* 233 */     return this.time7;
/*     */   }
/*     */   public void setTime7(Long time7) {
/* 236 */     this.time7 = time7;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 240 */     return "PortalbasauthView [username0=" + this.username0 + ", password0=" + 
/* 241 */       this.password0 + ", url0=" + this.url0 + ", time0=" + this.time0 + 
/* 242 */       ", username1=" + this.username1 + ", password1=" + this.password1 + 
/* 243 */       ", url1=" + this.url1 + ", time1=" + this.time1 + ", username2=" + 
/* 244 */       this.username2 + ", password2=" + this.password2 + ", url2=" + this.url2 + 
/* 245 */       ", time2=" + this.time2 + ", username3=" + this.username3 + 
/* 246 */       ", password3=" + this.password3 + ", url3=" + this.url3 + ", time3=" + 
/* 247 */       this.time3 + ", username4=" + this.username4 + ", password4=" + 
/* 248 */       this.password4 + ", url4=" + this.url4 + ", time4=" + this.time4 + 
/* 249 */       ", username5=" + this.username5 + ", password5=" + this.password5 + 
/* 250 */       ", url5=" + this.url5 + ", time5=" + this.time5 + ", username6=" + 
/* 251 */       this.username6 + ", password6=" + this.password6 + ", url6=" + this.url6 + 
/* 252 */       ", time6=" + this.time6 + ", username7=" + this.username7 + 
/* 253 */       ", password7=" + this.password7 + ", url7=" + this.url7 + ", time7=" + 
/* 254 */       this.time7 + "]";
/*     */   }
/*     */ }

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.core.query.PortalbasauthView
 * JD-Core Version:    0.6.2
 */