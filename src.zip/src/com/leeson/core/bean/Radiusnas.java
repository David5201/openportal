/*     */ package com.leeson.core.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Radiusnas
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Long id;
/*     */   private String ip;
/*     */   private String name;
/*     */   private String description;
/*     */   private String type;
/*     */   private String sharedSecret;
/*     */   private String ex1;
/*     */   private String ex2;
/*     */   private String ex3;
/*     */   private String ex4;
/*     */   private String ex5;
/*     */   private String ex6;
/*     */   private String ex7;
/*     */   private String ex8;
/*     */   private String ex9;
/*     */   private String ex10;
/*     */ 
/*     */   public Long getId()
/*     */   {
/*  34 */     return this.id;
/*     */   }
/*     */   public void setId(Long id) {
/*  37 */     this.id = id;
/*     */   }
/*     */   public String getIp() {
/*  40 */     return this.ip;
/*     */   }
/*     */   public void setIp(String ip) {
/*  43 */     this.ip = ip;
/*     */   }
/*     */   public String getName() {
/*  46 */     return this.name;
/*     */   }
/*     */   public void setName(String name) {
/*  49 */     this.name = name;
/*     */   }
/*     */   public String getDescription() {
/*  52 */     return this.description;
/*     */   }
/*     */   public void setDescription(String description) {
/*  55 */     this.description = description;
/*     */   }
/*     */   public String getType() {
/*  58 */     return this.type;
/*     */   }
/*     */   public void setType(String type) {
/*  61 */     this.type = type;
/*     */   }
/*     */   public String getSharedSecret() {
/*  64 */     return this.sharedSecret;
/*     */   }
/*     */   public void setSharedSecret(String sharedSecret) {
/*  67 */     this.sharedSecret = sharedSecret;
/*     */   }
/*     */   public String getEx1() {
/*  70 */     return this.ex1;
/*     */   }
/*     */   public void setEx1(String ex1) {
/*  73 */     this.ex1 = ex1;
/*     */   }
/*     */   public String getEx2() {
/*  76 */     return this.ex2;
/*     */   }
/*     */   public void setEx2(String ex2) {
/*  79 */     this.ex2 = ex2;
/*     */   }
/*     */   public String getEx3() {
/*  82 */     return this.ex3;
/*     */   }
/*     */   public void setEx3(String ex3) {
/*  85 */     this.ex3 = ex3;
/*     */   }
/*     */   public String getEx4() {
/*  88 */     return this.ex4;
/*     */   }
/*     */   public void setEx4(String ex4) {
/*  91 */     this.ex4 = ex4;
/*     */   }
/*     */   public String getEx5() {
/*  94 */     return this.ex5;
/*     */   }
/*     */   public void setEx5(String ex5) {
/*  97 */     this.ex5 = ex5;
/*     */   }
/*     */   public String getEx6() {
/* 100 */     return this.ex6;
/*     */   }
/*     */   public void setEx6(String ex6) {
/* 103 */     this.ex6 = ex6;
/*     */   }
/*     */   public String getEx7() {
/* 106 */     return this.ex7;
/*     */   }
/*     */   public void setEx7(String ex7) {
/* 109 */     this.ex7 = ex7;
/*     */   }
/*     */   public String getEx8() {
/* 112 */     return this.ex8;
/*     */   }
/*     */   public void setEx8(String ex8) {
/* 115 */     this.ex8 = ex8;
/*     */   }
/*     */   public String getEx9() {
/* 118 */     return this.ex9;
/*     */   }
/*     */   public void setEx9(String ex9) {
/* 121 */     this.ex9 = ex9;
/*     */   }
/*     */   public String getEx10() {
/* 124 */     return this.ex10;
/*     */   }
/*     */   public void setEx10(String ex10) {
/* 127 */     this.ex10 = ex10;
/*     */   }
/*     */   public String toString() {
/* 130 */     return "Radiusnas [id=" + this.id + ",ip=" + this.ip + ",name=" + this.name + ",description=" + this.description + ",type=" + this.type + ",sharedSecret=" + this.sharedSecret + ",ex1=" + this.ex1 + ",ex2=" + this.ex2 + ",ex3=" + this.ex3 + ",ex4=" + this.ex4 + ",ex5=" + this.ex5 + ",ex6=" + this.ex6 + ",ex7=" + this.ex7 + ",ex8=" + this.ex8 + ",ex9=" + this.ex9 + ",ex10=" + this.ex10 + "]";
/*     */   }
/*     */ }

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.core.bean.Radiusnas
 * JD-Core Version:    0.6.2
 */