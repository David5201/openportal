/*     */ package com.leeson.core.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class Historyonline
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Long id;
/*     */   private Long counts;
/*     */   private Date recDate;
/*     */   private Integer recYear;
/*     */   private Integer recMonth;
/*     */   private Integer recDay;
/*     */   private Integer recWeek;
/*     */   private Integer recTime;
/*     */   private String ex1;
/*     */   private String ex2;
/*     */   private String ex3;
/*     */   private String ex4;
/*     */   private String ex5;
/*     */   private String ex6;
/*     */   private String ex7;
/*     */   private String ex8;
/*     */   private String ex9;
/*     */   private String ex10;
/*     */ 
/*     */   public Long getId()
/*     */   {
/*  36 */     return this.id;
/*     */   }
/*     */   public void setId(Long id) {
/*  39 */     this.id = id;
/*     */   }
/*     */   public Long getCounts() {
/*  42 */     return this.counts;
/*     */   }
/*     */   public void setCounts(Long counts) {
/*  45 */     this.counts = counts;
/*     */   }
/*     */   public Date getRecDate() {
/*  48 */     return this.recDate;
/*     */   }
/*     */   public void setRecDate(Date recDate) {
/*  51 */     this.recDate = recDate;
/*     */   }
/*     */   public Integer getRecYear() {
/*  54 */     return this.recYear;
/*     */   }
/*     */   public void setRecYear(Integer recYear) {
/*  57 */     this.recYear = recYear;
/*     */   }
/*     */   public Integer getRecMonth() {
/*  60 */     return this.recMonth;
/*     */   }
/*     */   public void setRecMonth(Integer recMonth) {
/*  63 */     this.recMonth = recMonth;
/*     */   }
/*     */   public Integer getRecDay() {
/*  66 */     return this.recDay;
/*     */   }
/*     */   public void setRecDay(Integer recDay) {
/*  69 */     this.recDay = recDay;
/*     */   }
/*     */   public Integer getRecWeek() {
/*  72 */     return this.recWeek;
/*     */   }
/*     */   public void setRecWeek(Integer recWeek) {
/*  75 */     this.recWeek = recWeek;
/*     */   }
/*     */   public Integer getRecTime() {
/*  78 */     return this.recTime;
/*     */   }
/*     */   public void setRecTime(Integer recTime) {
/*  81 */     this.recTime = recTime;
/*     */   }
/*     */   public String getEx1() {
/*  84 */     return this.ex1;
/*     */   }
/*     */   public void setEx1(String ex1) {
/*  87 */     this.ex1 = ex1;
/*     */   }
/*     */   public String getEx2() {
/*  90 */     return this.ex2;
/*     */   }
/*     */   public void setEx2(String ex2) {
/*  93 */     this.ex2 = ex2;
/*     */   }
/*     */   public String getEx3() {
/*  96 */     return this.ex3;
/*     */   }
/*     */   public void setEx3(String ex3) {
/*  99 */     this.ex3 = ex3;
/*     */   }
/*     */   public String getEx4() {
/* 102 */     return this.ex4;
/*     */   }
/*     */   public void setEx4(String ex4) {
/* 105 */     this.ex4 = ex4;
/*     */   }
/*     */   public String getEx5() {
/* 108 */     return this.ex5;
/*     */   }
/*     */   public void setEx5(String ex5) {
/* 111 */     this.ex5 = ex5;
/*     */   }
/*     */   public String getEx6() {
/* 114 */     return this.ex6;
/*     */   }
/*     */   public void setEx6(String ex6) {
/* 117 */     this.ex6 = ex6;
/*     */   }
/*     */   public String getEx7() {
/* 120 */     return this.ex7;
/*     */   }
/*     */   public void setEx7(String ex7) {
/* 123 */     this.ex7 = ex7;
/*     */   }
/*     */   public String getEx8() {
/* 126 */     return this.ex8;
/*     */   }
/*     */   public void setEx8(String ex8) {
/* 129 */     this.ex8 = ex8;
/*     */   }
/*     */   public String getEx9() {
/* 132 */     return this.ex9;
/*     */   }
/*     */   public void setEx9(String ex9) {
/* 135 */     this.ex9 = ex9;
/*     */   }
/*     */   public String getEx10() {
/* 138 */     return this.ex10;
/*     */   }
/*     */   public void setEx10(String ex10) {
/* 141 */     this.ex10 = ex10;
/*     */   }
/*     */   public String toString() {
/* 144 */     return "Historyonline [id=" + this.id + ",counts=" + this.counts + ",recDate=" + this.recDate + ",recYear=" + this.recYear + ",recMonth=" + this.recMonth + ",recDay=" + this.recDay + ",recWeek=" + this.recWeek + ",recTime=" + this.recTime + ",ex1=" + this.ex1 + ",ex2=" + this.ex2 + ",ex3=" + this.ex3 + ",ex4=" + this.ex4 + ",ex5=" + this.ex5 + ",ex6=" + this.ex6 + ",ex7=" + this.ex7 + ",ex8=" + this.ex8 + ",ex9=" + this.ex9 + ",ex10=" + this.ex10 + "]";
/*     */   }
/*     */ }

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.core.bean.Historyonline
 * JD-Core Version:    0.6.2
 */