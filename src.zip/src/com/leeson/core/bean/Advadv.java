/*     */ package com.leeson.core.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class Advadv
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Long id;
/*     */   private String name;
/*     */   private String description;
/*     */   private Date creatDate;
/*     */   private Integer state;
/*     */   private Date showDate;
/*     */   private Date endDate;
/*     */   private Long uid;
/*     */   private Long sid;
/*     */   private Long pos;
/*     */   private String img;
/*     */   private Integer showName;
/*     */   private Integer showInfo;
/*     */   private Integer showImg;
/*     */   private Long showCount;
/*     */   private Long clickCount;
/*     */   private String url;
/*     */   private Long lockTime;
/*     */ 
/*     */   public Long getId()
/*     */   {
/*  36 */     return this.id;
/*     */   }
/*     */   public void setId(Long id) {
/*  39 */     this.id = id;
/*     */   }
/*     */   public String getName() {
/*  42 */     return this.name;
/*     */   }
/*     */   public void setName(String name) {
/*  45 */     this.name = name;
/*     */   }
/*     */   public String getDescription() {
/*  48 */     return this.description;
/*     */   }
/*     */   public void setDescription(String description) {
/*  51 */     this.description = description;
/*     */   }
/*     */   public Date getCreatDate() {
/*  54 */     return this.creatDate;
/*     */   }
/*     */   public void setCreatDate(Date creatDate) {
/*  57 */     this.creatDate = creatDate;
/*     */   }
/*     */   public Integer getState() {
/*  60 */     return this.state;
/*     */   }
/*     */   public void setState(Integer state) {
/*  63 */     this.state = state;
/*     */   }
/*     */   public Date getShowDate() {
/*  66 */     return this.showDate;
/*     */   }
/*     */   public void setShowDate(Date showDate) {
/*  69 */     this.showDate = showDate;
/*     */   }
/*     */   public Date getEndDate() {
/*  72 */     return this.endDate;
/*     */   }
/*     */   public void setEndDate(Date endDate) {
/*  75 */     this.endDate = endDate;
/*     */   }
/*     */   public Long getUid() {
/*  78 */     return this.uid;
/*     */   }
/*     */   public void setUid(Long uid) {
/*  81 */     this.uid = uid;
/*     */   }
/*     */   public Long getSid() {
/*  84 */     return this.sid;
/*     */   }
/*     */   public void setSid(Long sid) {
/*  87 */     this.sid = sid;
/*     */   }
/*     */   public Long getPos() {
/*  90 */     return this.pos;
/*     */   }
/*     */   public void setPos(Long pos) {
/*  93 */     this.pos = pos;
/*     */   }
/*     */   public String getImg() {
/*  96 */     return this.img;
/*     */   }
/*     */   public void setImg(String img) {
/*  99 */     this.img = img;
/*     */   }
/*     */   public Integer getShowName() {
/* 102 */     return this.showName;
/*     */   }
/*     */   public void setShowName(Integer showName) {
/* 105 */     this.showName = showName;
/*     */   }
/*     */   public Integer getShowInfo() {
/* 108 */     return this.showInfo;
/*     */   }
/*     */   public void setShowInfo(Integer showInfo) {
/* 111 */     this.showInfo = showInfo;
/*     */   }
/*     */   public Integer getShowImg() {
/* 114 */     return this.showImg;
/*     */   }
/*     */   public void setShowImg(Integer showImg) {
/* 117 */     this.showImg = showImg;
/*     */   }
/*     */   public Long getShowCount() {
/* 120 */     return this.showCount;
/*     */   }
/*     */   public void setShowCount(Long showCount) {
/* 123 */     this.showCount = showCount;
/*     */   }
/*     */   public Long getClickCount() {
/* 126 */     return this.clickCount;
/*     */   }
/*     */   public void setClickCount(Long clickCount) {
/* 129 */     this.clickCount = clickCount;
/*     */   }
/*     */   public String getUrl() {
/* 132 */     return this.url;
/*     */   }
/*     */   public void setUrl(String url) {
/* 135 */     this.url = url;
/*     */   }
/*     */   public Long getLockTime() {
/* 138 */     return this.lockTime;
/*     */   }
/*     */   public void setLockTime(Long lockTime) {
/* 141 */     this.lockTime = lockTime;
/*     */   }
/*     */   public String toString() {
/* 144 */     return "Advadv [id=" + this.id + ",name=" + this.name + ",description=" + this.description + ",creatDate=" + this.creatDate + ",state=" + this.state + ",showDate=" + this.showDate + ",endDate=" + this.endDate + ",uid=" + this.uid + ",sid=" + this.sid + ",pos=" + this.pos + ",img=" + this.img + ",showName=" + this.showName + ",showInfo=" + this.showInfo + ",showImg=" + this.showImg + ",showCount=" + this.showCount + ",clickCount=" + this.clickCount + ",url=" + this.url + ",lockTime=" + this.lockTime + "]";
/*     */   }
/*     */ }

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.core.bean.Advadv
 * JD-Core Version:    0.6.2
 */