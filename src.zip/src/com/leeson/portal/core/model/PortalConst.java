package com.leeson.portal.core.model;

public class PortalConst
{
  public static final String PORTAL_LOGIN = "PORTAL_LOGIN";
  public static final String PORTAL_LOGINOUT = "PORTAL_LOGINOUT";
  public static final String PAP = "0";
  public static final String CHAP = "1";
  public static final String HUAWEI = "0";
  public static final String H3C = "1";
  public static final String IKUAI = "2";
  public static final String UNIFI = "3";
  public static final String ZM = "4";
  public static final String ROS = "5";
  public static final String RUCKUS = "6";
  public static final String ARUBA = "7";
  public static final String TPLINK = "8";
  public static final String OL = "已超过允许最大用户数限制！！";
}

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.portal.core.model.PortalConst
 * JD-Core Version:    0.6.2
 */