/*    */ package com.leeson.portal.core.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ public class WySlot15gasa
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 395879148380019800L;
/* 11 */   private Map<String, String[]> AmkbYQX3eQjuwtnxpbjYgQGZOr = new ConcurrentHashMap();
/*    */ 
/* 13 */   private static WySlot15gasa instance = new WySlot15gasa();
/*    */ 
/*    */   public static WySlot15gasa getInstance()
/*    */   {
/* 19 */     return instance;
/*    */   }
/*    */ 
/*    */   public Map<String, String[]> getAmkbYQX3eQjuwtnxpbjYgQGZOr() {
/* 23 */     return this.AmkbYQX3eQjuwtnxpbjYgQGZOr;
/*    */   }
/*    */ 
/*    */   public void setAmkbYQX3eQjuwtnxpbjYgQGZOr(Map<String, String[]> amkbYQX3eQjuwtnxpbjYgQGZOr)
/*    */   {
/* 28 */     this.AmkbYQX3eQjuwtnxpbjYgQGZOr = amkbYQX3eQjuwtnxpbjYgQGZOr;
/*    */   }
/*    */ }

/* Location:           C:\Users\Thinkpad\Desktop\Tool\jd-gui\jd-gui\spring-ops-3.2.4.RELEASE.jar
 * Qualified Name:     com.leeson.portal.core.model.WySlot15gasa
 * JD-Core Version:    0.6.2
 */